<?php


if (!function_exists('imagePath')) {

   function Utils () {


           return url('https://peapiuat.dreamplesk.com/public/uploads/featuredproperty/images/');



   }

}

if (!function_exists('imageAgent')) {

    function AgentImage () {


        return url('https://peapiuat.dreamplesk.com/public/uploads/featuredagent/images/');



    }

}
