<div class="row">
    <?php if($paginator->hasPages()): ?>
    <div class="col-lg-12 col-md-12 col-sm-12">
        <ul class="pagination p-center">
        <?php if($paginator->onFirstPage()): ?>
            <li class="page-item disabled">
                <a class="page-link"  href="#" aria-label="Previous">
                    <span class="ti-arrow-left"></span>
                    <span class="sr-only">Previous</span>
                </a>
            </li>
        <?php else: ?>
            <li class="page-item">
                <a class="page-link" data-page="<?php echo e($paginator->currentPage() -1); ?>" href="javascript:void(0);" aria-label="Previous">
                    <span class="ti-arrow-left"></span>
                    <span class="sr-only">Previous</span>
                </a>
            </li>
        <?php endif; ?>

            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_string($element)): ?>
                <li class="page-item disabled"><?php echo e($element); ?></li>
            <?php endif; ?>

                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
            <li class="page-item active">
                <a class="page-link active" data-page="<?php echo e($page); ?>"  href="javascript:void(0);"><?php echo e($page); ?></a>
            </li>
                        <?php else: ?>
                            <li class="page-item " >
                                <a class="page-link " data-page="<?php echo e($page); ?>"  href="javascript:void(0);"><?php echo e($page); ?></a>
                            </li>
                            <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link" data-page="<?php echo e($paginator->currentPage()+1); ?>" href="javascript:void(0);" aria-label="Next">
                        <span class="ti-arrow-right"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link" data-page="<?php echo e($paginator->currentPage()); ?>" href="javascript:void(0);" aria-label="Next">
                        <span class="ti-arrow-right"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </li>
            <?php endif; ?>

        </ul>
    </div>
        <?php endif; ?>

<?php /**PATH D:\php\htdocs\propTesting\pecustomeruat\resources\views/components/custompagination.blade.php ENDPATH**/ ?>