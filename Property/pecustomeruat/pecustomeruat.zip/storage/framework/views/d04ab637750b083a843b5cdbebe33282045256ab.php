
<?php $__env->startSection('content'); ?>

    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">

                    <h2 class="ipt-title">Property List</h2>


                </div>
            </div>
        </div>
    </div>
    <!-- ============================ Page Title End ================================== -->

    <!-- ============================ All Property ================================== -->
    <section class="gray">

        <div class="container">
            <div class="row">

                <!-- property Sidebar -->
                <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="simple-sidebar sm-sidebar" id="filter_search"  style="left:0;">

                        <div class="search-sidebar_header">
                            <h4 class="ssh_heading">Close Filter</h4>
                            <button onclick="" class="w3-bar-item w3-button w3-large"><i class="ti-close"></i></button>
                        </div>

                        <!-- Find New Property -->
                        <div class="sidebar-widgets">

                            <div class="search-inner p-0">










                                <div class="filter_wraps">

                                    <!-- Single Search -->
                                    <div class="single_search_boxed">
                                        <div class="widget-boxed-header">
                                            <h4>
                                                <a href="#where" data-bs-toggle="collapse" aria-expanded="false" role="button" class="collapsed">Where<span class="selected"></span></a>
                                            </h4>

                                        </div>
                                        <div class="widget-boxed-body collapse" id="where" data-parent="#where">
                                            <div class="side-list no-border">
                                                <!-- Single Filter Card -->
                                                <div class="single_filter_card">
                                                    <div class="card-body pt-0">
                                                        <div class="inner_widget_link">
                                                            <ul class="no-ul-list filter-list">
                                                                <input type="hidden"  id="cpt" value="<?php echo e($fetch->cpt); ?>" name="cpt">

                                                                <?php $__currentLoopData = $town; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($city->town_name==$fetch->location): ?>
                                                                        <li>
                                                                            <input id="b<?php echo e($city->town_id); ?>" onclick="properties(1)" class="radio-custom" value="<?php echo e($city->town_name); ?>"  name="towncity" type="radio" checked>
                                                                            <label for="b<?php echo e($city->town_id); ?>" class="radio-custom-label"><?php echo e($city->town_name); ?></label>
                                                                        </li>

                                                                    <?php else: ?>
                                                                        <li>
                                                                            <input id="b<?php echo e($city->town_id); ?>" onclick="properties(1)" class="radio-custom" value="<?php echo e($city->town_name); ?>" name="towncity" type="radio">
                                                                            <label for="b<?php echo e($city->town_id); ?>" class="radio-custom-label"><?php echo e($city->town_name); ?></label>
                                                                        </li>
                                                                        <?php endif; ?>


                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Single Search -->
                                    <div class="single_search_boxed">
                                        <div class="widget-boxed-header">
                                            <h4>
                                                <a href="#fptype" data-bs-toggle="collapse" aria-expanded="false" role="button" class="collapsed">Property Types<span class="selected"></span></a>
                                            </h4>

                                        </div>
                                        <div class="widget-boxed-body collapse" id="fptype" data-parent="#fptype">
                                            <div class="side-list no-border">
                                                <!-- Single Filter Card -->
                                                <div class="single_filter_card">
                                                    <div class="card-body pt-0">
                                                        <div class="inner_widget_link">
                                                            <ul class="no-ul-list filter-list">

                                                                <?php $__currentLoopData = $propertytypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($type->property_type_id==$fetch->propertytype): ?>
                                                                        <li>
                                                                            <input id="c<?php echo e($type->property_type_id); ?>" onclick="properties(1)" class="radio-custom" name="ptype" type="radio" value="<?php echo e($type->property_type_id); ?>" checked>
                                                                            <label for="c<?php echo e($type->property_type_id); ?>" class="radio-custom-label"><?php echo e($type->property_type); ?></label>
                                                                        </li>
                                                                    <?php else: ?>
                                                                        <li>
                                                                            <input id="c<?php echo e($type->property_type_id); ?>" onclick="properties(1)" class="radio-custom" name="ptype" type="radio" value="<?php echo e($type->property_type_id); ?>">
                                                                            <label for="c<?php echo e($type->property_type_id); ?>" class="radio-custom-label"><?php echo e($type->property_type); ?></label>
                                                                        </li>
                                                                        <?php endif; ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Single Search -->
                                    <div class="single_search_boxed">
                                        <div class="widget-boxed-header">
                                            <h4>
                                                <a href="#fbedrooms" data-bs-toggle="collapse" aria-expanded="false" role="button" class="collapsed">Bedrooms<span class="selected"></span></a>
                                            </h4>

                                        </div>
                                        <div class="widget-boxed-body collapse" id="fbedrooms" data-parent="#fbedrooms">
                                            <div class="side-list no-border">
                                                <!-- Single Filter Card -->
                                                <div class="single_filter_card">
                                                    <div class="card-body pt-0">
                                                        <div class="inner_widget_link">
                                                            <ul class="no-ul-list filter-list">
                                                                <li>

                                                                    <?php if($fetch->nobedrooms==1): ?>
                                                                    <input id="a1" onclick="properties(1)" class="radio-custom" checked  name="bed" type="radio" value="1">
                                                                    <label for="a1" class="radio-custom-label">01 Bedrooms</label>
                                                                    <?php else: ?>
                                                                        <input id="a1" onclick="properties(1)" class="radio-custom"  name="bed" type="radio" value="1">
                                                                        <label for="a1" class="radio-custom-label">01 Bedrooms</label>
                                                                    <?php endif; ?>
                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->nobedrooms==2): ?>
                                                                    <input id="a2"  onclick="properties(1)"  class="radio-custom" name="bed"  checked   value="2" type="radio">
                                                                    <label for="a2" class="radio-custom-label">02 Bedrooms</label>
                                                                    <?php else: ?>
                                                                        <input id="a2" onclick="properties(1)" class="radio-custom"  name="bed" type="radio" value="2">
                                                                        <label for="a2" class="radio-custom-label">02 Bedrooms</label>
                                                                    <?php endif; ?>

                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->nobedrooms==3): ?>
                                                                    <input id="a3" onclick="properties(1)"  class="radio-custom" name="bed"  checked  value="3" type="radio">
                                                                    <label for="a3" class="radio-custom-label" >03 Bedrooms</label>
                                                                    <?php else: ?>
                                                                        <input id="a3" onclick="properties(1)" class="radio-custom"  name="bed" type="radio" value="3">
                                                                        <label for="a3" class="radio-custom-label">03 Bedrooms</label>
                                                                    <?php endif; ?>
                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->nobedrooms==4): ?>
                                                                    <input id="a4" onclick="properties(1)"  class="radio-custom" name="bed"  checked   type="radio" value="4" >
                                                                    <label for="a4" class="radio-custom-label" >04 Bedrooms</label>
                                                                    <?php else: ?>
                                                                        <input id="a4" onclick="properties(1)" class="radio-custom"  name="bed" type="radio" value="4">
                                                                        <label for="a4" class="radio-custom-label">04 Bedrooms</label>
                                                                    <?php endif; ?>
                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->nobedrooms==5): ?>
                                                                    <input id="a5" onclick="properties(1)"  class="radio-custom" name="bed"  checked  type="radio" value="5">
                                                                    <label for="a5" class="radio-custom-label" >05 Bedrooms</label>
                                                                    <?php else: ?>
                                                                        <input id="a5" onclick="properties(1)" class="radio-custom"  name="bed" type="radio" value="5">
                                                                        <label for="a5" class="radio-custom-label">05 Bedrooms</label>
                                                                    <?php endif; ?>
                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->nobedrooms==6): ?>
                                                                    <input id="a6" onclick="properties(1)"  class="radio-custom" name="bed"   checked  type="radio" value="6">
                                                                    <label for="a6" class="radio-custom-label" >06+ Bedrooms</label>
                                                                    <?php else: ?>
                                                                        <input id="a6" onclick="properties(1)" class="radio-custom"  name="bed" type="radio" value="6">
                                                                        <label for="a6" class="radio-custom-label">06 Bedrooms</label>
                                                                    <?php endif; ?>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Single Search -->
                                    <div class="single_search_boxed">
                                        <div class="widget-boxed-header">
                                            <h4>
                                                <a href="#fprice" data-bs-toggle="collapse" aria-expanded="false" role="button" class="collapsed">Price Range<span class="selected"></span></a>
                                            </h4>

                                        </div>
                                        <div class="widget-boxed-body collapse" id="fprice" data-parent="#fprice">
                                            <div class="side-list no-border">
                                                <!-- Single Filter Card -->
                                                <div class="single_filter_card">
                                                    <div class="card-body pt-0">
                                                        <div class="inner_widget_link">
                                                            <ul class="no-ul-list filter-list">
                                                                <li>
                                                                    <?php if($fetch->singleprice==1): ?>
                                                                        <input id="e1" onclick="properties(1)" class="radio-custom" name="prices" checked type="radio" value="1">
                                                                        <label for="e1" class="radio-custom-label">Less Then $10,000</label>
                                                                      <?php else: ?>
                                                                        <input id="e1" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="1">
                                                                        <label for="e1" class="radio-custom-label">Less Then $10,000</label>
                                                                        <?php endif; ?>

                                                                </li>
                                                                <li>
                                                                      <?php if($fetch->singleprice==2): ?>
                                                                        <input id="e2" onclick="properties(1)" class="radio-custom" name="prices" type="radio" checked value="2">
                                                                        <label for="e2" class="radio-custom-label">$10,000 - $15,000</label>
                                                                      <?php else: ?>
                                                                        <input id="e2" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="2">
                                                                        <label for="e2" class="radio-custom-label">$10,000 - $15,000</label>
                                                                        <?php endif; ?>

                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->singleprice==3): ?>
                                                                        <input id="e3"  onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="3" checked>
                                                                        <label for="e3" class="radio-custom-label">$12,000 - $25,000</label>
                                                                       <?php else: ?>
                                                                        <input id="e3"  onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="3">
                                                                        <label for="e3" class="radio-custom-label">$12,000 - $25,000</label>
                                                                        <?php endif; ?>

                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->singleprice==4): ?>
                                                                        <input id="e4" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="4" checked>
                                                                        <label for="e4" class="radio-custom-label">$30,000 - $35,000</label>
                                                                    <?php else: ?>
                                                                        <input id="e4" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="4">
                                                                        <label for="e4" class="radio-custom-label">$30,000 - $35,000</label>
                                                                    <?php endif; ?>

                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->singleprice==5): ?>
                                                                        <input id="e5" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="5" checked>
                                                                        <label for="e5" class="radio-custom-label">$40,000 - $45,000</label>
                                                                    <?php else: ?>
                                                                        <input id="e6" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="5">
                                                                        <label for="e6" class="radio-custom-label">$40,000 - $45,000</label>
                                                                        <?php endif; ?>

                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->singleprice==6): ?>
                                                                        <input id="e6" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="6" checked>
                                                                        <label for="e6" class="radio-custom-label">$50,000 - $55,000</label>
                                                                    <?php else: ?>
                                                                        <input id="e6" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="6" >
                                                                        <label for="e6" class="radio-custom-label">$50,000 - $55,000</label>
                                                                    <?php endif; ?>

                                                                </li>
                                                                <li>
                                                                    <?php if($fetch->singleprice==7): ?>
                                                                        <input id="e7" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="7" checked>
                                                                        <label for="e7" class="radio-custom-label">$60,000 - $65,000</label>
                                                                    <?php else: ?>
                                                                        <input id="e7" onclick="properties(1)" class="radio-custom" name="prices" type="radio" value="7">
                                                                        <label for="e7" class="radio-custom-label">$60,000 - $65,000</label>
                                                                    <?php endif; ?>

                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Single Search -->


                                    <!-- Single Search -->
                                    <div class="single_search_boxed">
                                        <div class="widget-boxed-header">
                                            <h4>
                                                <a href="#ameneties" data-bs-toggle="collapse" aria-expanded="false" role="button" class="collapsed">Ameneties<span class="selected">ADA Compliant</span></a>
                                            </h4>

                                        </div>
                                        <div class="widget-boxed-body collapse" id="ameneties" data-parent="#ameneties">
                                            <div class="side-list no-border">
                                                <!-- Single Filter Card -->
                                                <div class="single_filter_card">
                                                    <div class="card-body pt-0">
                                                        <div class="inner_widget_link">
                                                            <ul class="no-ul-list filter-list">
                                                                <?php
                                                                    $amenities=DB::table('master_amenities')->where('status','Active')->get()
                                                                ?>
                                                                <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                    <li>
                                                                        <input id="g<?php echo e($amenities->id); ?>" class="checkbox-custom" name="ADA" type="checkbox" onclick="properties(1)" name="amenities" value="<?php echo e($amenities->id); ?>">
                                                                        <label for="g<?php echo e($amenities->id); ?>" class="checkbox-custom-label"><?php echo e($amenities->name); ?></label>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                  <?php if($fetch->nobathrooms): ?>
                                                                  <input type="hidden" name="nobathrooms" value="<?php echo e($fetch->nobathrooms); ?>">
                                                                    <?php endif; ?>

                                                                <?php if($fetch->location): ?>
                                                                    <input type="hidden" name="nolocation" value="<?php echo e($fetch->location); ?>">
                                                                <?php endif; ?>






                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>


                            </div>
                        </div>
                    </div>
                    <!-- Sidebar End -->

                </div>


                <div class="col-lg-8 col-md-12 list-layout">

                    <div class="row justify-content-center">
                        <div class="col-lg-12 col-md-12">
                            <div class="item-shorting-box">
                                <div class="item-shorting clearfix">

                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="row" id="appenddata">


                        <!-- Single Property End -->

                        <!-- Single Property Start -->

                        <!-- Single Property End -->

                    </div>

                    <!-- Pagination -->
                    <div class="row" id="pagination">

                    </div>

                </div>

            </div>
        </div>
    </section>
    <!-- ============================ All Property ================================== -->
    <script>
        $(document).ready(function () {
            properties(1);
            $('#pageno').text(1);
        });
        function properties(page) {
            var a=[];

            var page=page;
            $("input:checkbox[name='ADA']:checked").each(function(){
                a.push($(this).val());
            });
            var price =  $("input:radio[name='prices']:checked").val();
            var nolocation =  $("input:hidden[name='nolocation']").val();
            var nobathrooms =  $("input:hidden[name='nobathrooms']").val();

            var ptype =  $("input:radio[name='ptype']:checked").val();
            var towncity =  $("input:radio[name='towncity']:checked").val();
            if(towncity){
                var nolocation='';
            }
            var bed =  $("input:radio[name='bed']:checked").val();
            var cpt=$('#cpt').val();
            var product_category_name = $("input:radio[name='product_category_name']:checked").val();
            $.ajax({
                type: 'GET',
                url: "<?php echo e(route('getsearchfilter')); ?>",
                data: {
                    location:nolocation,
                    page:page,
                    cpt:cpt,
                    amenities_id:a,
                    nobathrooms:nobathrooms,
                    singleprice:price,
                    propertytype:ptype,
                    towncity:towncity,
                    nobedrooms:bed,

                    product_category_name:product_category_name,
                },
                success: function (response) {
                    $('#appenddata').html(response.html);
                    $('#pagination').html(response.pagination);
                },
            });
        }
        $(document).on("click", ".pagination li a", function(e){
            e.preventDefault();
            var pageId = $(this).attr("data-page");

            properties(pageId);
            $('#pageno').text(pageId);
        });
    </script>
    <!-- ============================ Call To Action ================================== -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.Layouts.frontendlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\htdocs\propTesting\pecustomeruat\resources\views/Frontend/newpropertylist.blade.php ENDPATH**/ ?>