
<?php $__env->startSection('content'); ?>
<div class="featured_slick_gallery gray">

   <?php
   $path=Utils();

   ?>

   <div class="featured_slick_gallery-slide">
      <?php $__currentLoopData = $property_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="featured_slick_padd"><a href="<?php echo e($path); ?><?php echo e($propertyi->images_video); ?>" class="mfp-gallery"><img src="<?php echo e($path); ?><?php echo e($propertyi->images_video); ?>" class="img-fluid mx-auto" alt="" /></a></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


   </div>
   <!-- <a href="JavaScript:Void(0);" class="btn-view-pic">View photos</a> -->


</div>
<!-- ============================ Hero Banner End ================================== -->

<!-- ============================ Property Detail Start ================================== -->
<section class="gray-simple">
   <div class="container">
      <div class="row">

         <!-- property main detail -->
         <div class="col-lg-8 col-md-12 col-sm-12">

            <div class="property_block_wrap style-2 p-4">
               <div class="prt-detail-title-desc">
                  <?php if($property->ProductCategory->product_category_name=='For Rent'): ?>
                  <span class="prt-types rent"><?php echo e($property->ProductCategory->product_category_name); ?></span>
                  <?php else: ?>
                  <span class="prt-types sale"><?php echo e($property->ProductCategory->product_category_name); ?></span>
                  <?php endif; ?>
                  <h3><?php echo e($property->property_name); ?></h3>
                  <span><i class="lni-map-marker"></i><?php echo e($property->street_name??''); ?></span>
				      <?php if($property->ProductCategory->product_category_name=='For Sale'): ?>
				      <h3 class="prt-price-fix">$<?php echo e($property->price_asked); ?><sub></sub></h3>
				   <?php else: ?>
				      <h3 class="prt-price-fix">$<?php echo e($property->price_asked); ?><sub>/month</sub></h3>
				   <?php endif; ?>
                 
                  <div class="list-fx-features">
                     <div class="listing-card-info-icon">
                        <div class="inc-fleat-icon"><img src="<?php echo e(url('/')); ?>/assets/frontend/img/bed.svg" width="13" alt=""></div> <?php echo e($property->no_bedrooms); ?> Beds
                     </div>
                     <div class="listing-card-info-icon">
                        <div class="inc-fleat-icon"><img src="<?php echo e(url('/')); ?>/assets/frontend/img/bathtub.svg" width="13" alt=""></div> <?php echo e($property->no_toilets); ?> Bath
                     </div>
                     <div class="listing-card-info-icon">
                        <div class="inc-fleat-icon"><img src="<?php echo e(url('/')); ?>/assets/frontend/img/move.svg" width="13" alt=""></div><?php echo e($property->land_area); ?> sqft
                     </div>
                  </div>
               </div>
            </div>

            <!-- Single Block Wrap -->
            <div class="property_block_wrap style-2">

               <div class="property_block_wrap_header">
                  <a data-bs-toggle="collapse" data-parent="#features" data-bs-target="#clOne" aria-controls="clOne" href="javascript:void(0);" aria-expanded="false"><h4 class="property_block_title">Detail & Features</h4></a>
               </div>
               <div id="clOne" class="panel-collapse collapse show" aria-labelledby="clOne">
                  <div class="block-body">
                     <ul class="deatil_features">
                        <li><strong>Bedrooms:</strong><?php echo e($property->no_bedrooms??''); ?> Beds</li>
                        <li><strong>Bathrooms:</strong><?php echo e($property->no_toilets??''); ?> Bath</li>
                        <li><strong>Areas:</strong><?php echo e($property->land_area??''); ?> sq ft</li>
                        <li><strong>Garage</strong><?php echo e($property->garage??''); ?></li>

                        <li><strong>Property Type:</strong> <?php echo e($property->PropertyType->property_type); ?></li>
                        <li><strong>Year:</strong>Built <?php echo e($property->year??''); ?></li>
                        <li><strong>Cooling:</strong><?php echo e($property->cooling??''); ?></li>
                        <li><strong>Heating Type:</strong><?php echo e($property->heatingtype??''); ?></li>
                        <li><strong>Kitchen Features:</strong><?php echo e($property->kitchen??''); ?></li>
                        <li><strong>Exterior:</strong><?php echo e($property->exteriour??''); ?></li>

                        <li><strong>Elevetor:</strong><?php echo e($property->elevator); ?></li>
                        <li><strong>Fireplace:</strong><?php echo e($property->fireplace??''); ?></li>
                        <li><strong>Free WiFi:</strong><?php echo e($property->freewifi??''); ?></li>

                     </ul>
                  </div>
               </div>

            </div>

            <!-- Single Block Wrap -->
            <div class="property_block_wrap style-2">

               <div class="property_block_wrap_header">
                  <a data-bs-toggle="collapse" data-parent="#dsrp" data-bs-target="#clTwo" aria-controls="clTwo" href="javascript:void(0);" aria-expanded="true"><h4 class="property_block_title">Description</h4></a>
               </div>
               <div id="clTwo" class="panel-collapse collapse show">
                  <div class="block-body">
                     <p><?php echo $property->property_description; ?></p>
                  </div>
               </div>
            </div>

            <!-- Single Block Wrap -->
            <div class="property_block_wrap style-2">

               <div class="property_block_wrap_header">
                  <a data-bs-toggle="collapse" data-parent="#amen"  data-bs-target="#clThree" aria-controls="clThree" href="javascript:void(0);" aria-expanded="true"><h4 class="property_block_title">Ameneties</h4></a>
               </div>

               <div id="clThree" class="panel-collapse collapse show">
                  <div class="block-body">
                     <ul class="avl-features third color">
                        <?php $__currentLoopData = $property_amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($prop->name); ?></li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                  </div>
               </div>
            </div>

            <!-- Single Block Wrap -->
            <div class="property_block_wrap style-2">

               <div class="property_block_wrap_header">
                  <a data-bs-toggle="collapse" data-parent="#vid"  data-bs-target="#clFour" aria-controls="clFour" href="javascript:void(0);" aria-expanded="true" class="collapsed"><h4 class="property_block_title">Property video</h4></a>
               </div>
              <?php $__currentLoopData = $property_video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <div id="clFour" class="panel-collapse collapse">
                  <div class="block-body">
                     <div class="property_video">
                        <div class="thumb">
                           <img class="pro_img img-fluid w100" src="<?php echo e(url('/')); ?>/assets/frontend/img/p-6.jpg" alt="7.jpg">
                           <div class="overlay_icon">
                              <div class="bb-video-box">
                                 <div class="bb-video-box-inner">
                                    <div class="bb-video-box-innerup">
                                       <a  data-src="<?php echo e($video->images_video); ?>" href="<?php echo e($video->images_video); ?>" data-bs-toggle="modal" data-bs-target="#myModal" class="theme-cl video-btn"><i class="ti-control-play"></i></a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Single Block Wrap -->
            <div class="property_block_wrap style-2">

               <div class="property_block_wrap_header">
                  <a data-bs-toggle="collapse" data-parent="#floor"  data-bs-target="#clFive" aria-controls="clFive" href="javascript:void(0);" aria-expanded="true" class="collapsed"><h4 class="property_block_title">Floor Plan</h4></a>
               </div>

               <div id="clFive" class="panel-collapse collapse">
                  <div class="block-body">
                     <div class="accordion" id="floor-option">
                       
                        <div class="card">
                           
                           <div class="card-header" id="firstFloor">
													<h2 class="mb-0">
														<button type="button" class="btn btn-link" data-bs-toggle="collapse" data-bs-target="#firstfloor" aria-controls="firstfloor">Land Area<span><?php echo e($property->land_area??''); ?> Sq M</span></button>									
													</h2>
												</div>

                        </div>


                        <div class="card">
                              <?php if($property->building_area!=null): ?>
                              <div class="card-header" id="firstFloor">
													<h2 class="mb-0">
														<button type="button" class="btn btn-link" data-bs-toggle="collapse" data-bs-target="#firstfloor" aria-controls="firstfloor">Building Area<span><?php echo e($property->building_area??''); ?> Sq M</span></button>									
													</h2>
												</div>
                              <?php else: ?>
                            
                              <?php endif; ?>
                           

                        </div>
                       


                     </div>
                  </div>
               </div>

            </div>


            <!-- Single Block Wrap -->
            <div class="property_block_wrap style-2">

               <div class="property_block_wrap_header">
                  <a data-bs-toggle="collapse" data-parent="#clSev"  data-bs-target="#clSev" aria-controls="clOne" href="javascript:void(0);" aria-expanded="true" class="collapsed"><h4 class="property_block_title">Gallery</h4></a>
               </div>

               <div id="clSev" class="panel-collapse collapse">
                  <div class="block-body">
                     <ul class="list-gallery-inline">
                        <?php $__currentLoopData = $property_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                           <a href="<?php echo e($path); ?><?php echo e($gallery->images_video); ?>" class="mfp-gallery"><img src="<?php echo e($path); ?><?php echo e($gallery->images_video); ?>" class="img-fluid mx-auto" alt="" /></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </ul>
                  </div>
               </div>

            </div>


         </div>

         <!-- property Sidebar -->
         <div class="col-lg-4 col-md-12 col-sm-12">

            <!-- Like And Share -->
            <div class="like_share_wrap b-0">
               <ul class="like_share_list">
                  <!--<li><a href="JavaScript:Void(0);" class="btn btn-likes" data-toggle="tooltip" data-original-title="Share"><i class="fas fa-share"></i>Share</a></li>-->
                  <!-- <li><a href="JavaScript:Void(0);" class="btn btn-likes" data-toggle="tooltip" data-original-title="Save"><i class="fas fa-heart"></i>Save</a></li> -->
               </ul>
            </div>

            <div class="details-sidebar">

               <!-- Agent Detail -->
               <div class="sides-widget">
                  <div class="sides-widget-header">
                     <div class="agent-photo"><img src="<?php echo e($agentimage); ?><?php echo e($phone->agent_photo); ?>" alt=""></div>
                     <div class="sides-widget-details">
                        <h4><a href="#">Contact</a></h4>
                               <?php $__currentLoopData = $property->PropertyAgent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <input type="hidden" name="property_id" value="<?php echo e($p->user_id); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               <span><i class="lni-phone-handset"></i><?php echo e($phone->phone_1??''); ?> </span>

                     </div>
                     <div class="clearfix"></div>
                  </div>
                   <form  id="enquiry" method="POST" action="<?php echo e(route('property-enquiry')); ?>">
                       <?php echo csrf_field(); ?>
                  <div class="sides-widget-body simple-form">
                      <input type="hidden" name="agent_id" value="<?php echo e($p->user_id??''); ?>">
                      <input type="hidden" name="property_id" value="<?php echo e($property->id??''); ?>">
                     <div class="form-group">
                        <label>Email</label>

                        <input type="text" class="form-control" placeholder="Your Email" name="email">
                         <i class="mdi mdi-check-circle-outline" id="email_err"></i>
                     </div>
                     <div class="form-group">
                        <label>Phone No.</label>
                        <input type="text" class="form-control" maxlength="12" placeholder="Your Phone" name="phone" id="mainphone">
                         <i class="mdi mdi-check-circle-outline" id="phone_err"></i>
                     </div>
                     <div class="form-group">
                        <label>Description</label>
                        <textarea  name="description" class="form-control"></textarea>
                         <i class="mdi mdi-check-circle-outline" id="description_err"></i>
                     </div>
                     <button id="btn_reg1" type="submit" class="btn btn-black btn-md rounded full-width">Send Message</button>
                  </div>
                   </form>
               </div>


               <!-- Featured Property -->
               <div class="sidebar-widgets">

                  <h4>Featured Property</h4>

                  <div class="sidebar_featured_property">
                      <?php $__currentLoopData = $propertyfeatured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php
                     $db=DB::table('property_images')->where('property_id',$p['id'])->where('type','Image')->first();

                     ?>

                     <div class="sides_list_property">


                        <div class="sides_list_property_thumb">
                           <img src="<?php echo e($path); ?><?php echo e($db->images_video??''); ?>" class="img-fluid" alt="">
                        </div>

                        <div class="sides_list_property_detail">
                           <h4><a href="<?php echo e(route('single-property',$p->slug)); ?>"><?php echo e($p->property_headline); ?></a></h4>
                        
                           <div class="lists_property_price">
                              <div class="lists_property_types">
                                 <div class="property_types_vlix sale"><?php echo e($p->ProductCategory->product_category_name); ?></div>
                              </div>
                              <div class="lists_property_price_value">
                                 <h4>$<?php echo e($p->price_asked); ?></h4>
                              </div>
                           </div>
                        </div>
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <!-- List Sibar Property -->
                     

                  </div>

               </div>

            </div>
         </div>

      </div>
   </div>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">


                <div class="modal-body">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></span>
                    </button>
                    <!-- 16:9 aspect ratio -->
                    <div class="ratio ratio-16x9">
                        <iframe class="embed-responsive-item" src="" id="video"  allowscriptaccess="always" allow="autoplay"></iframe>
                    </div>


                </div>

            </div>
        </div>
    </div>



    </div>



    </div>
</section>
<!-- ============================ Property Detail End ================================== -->
<script>

    $(document).ready(function() {

        toastr.options = {
            'closeButton': true,
            'debug': false,
            'newestOnTop': false,
            'progressBar': true,
            'preventDuplicates': false,
            'showDuration': '6000',
            'hideDuration': '6000',
            'timeOut': '1500',
            'extendedTimeOut': '1000',
            'showEasing': 'swing',
            'hideEasing': 'linear',
            'showMethod': 'fadeIn',
            'hideMethod': 'fadeOut',
        } });
</script>
    <script>

        $(document).on('submit', '#enquiry', function (e) {
        e.preventDefault();
        let form = $(this);
        let submit_btn = form.find('button[type=submit]');
        let formData = new FormData(this);
        $.ajax({
        type: 'post',
        dataType: 'json',
        url: form.attr('action'),
        data: formData,
        cache:false,
        contentType: false,
        processData: false,
        beforeSend:function (){
        $('#btn_reg1').html('Processing...');
    },
        success: function (response) {
        if ((response.status == 'success')) {
        $('#enquiry')[0].reset();
        toastr.success(response.msg);
    }
        else {
        printErrorMsg(response.error);

    }
    },
        complete:function (data){
        $('#btn_reg1').html('Send Message');
    },

    });

    });
        function printErrorMsg(msg) {
        $.each(msg, function (key, value) {
            $('#' + key + '_err').attr('class',' mdi mdi-check-circle-outline text-danger').text(value);

        });

        $('input').on('keyup', function () {
        var key = $(this).attr('name');

        if ($(this).val() === '') {
        $('#' + key + '_err').attr('class','mdi mdi-check-circle-outline text-danger').show();
    } else {
        $('#' + key + '_err').hide();
    }
    })
        $('textarea').on('keyup', function () {
        var key = $(this).attr('name');
        if ($(this).val() === '') {
        $('#' + key + '_err').attr('class','mdi mdi-check-circle-outline text-danger').show();
    } else {
        $('#' + key + '_err').hide();
    }
    })
    }
</script>
<script>
    $(document).ready(function() {

// Gets the video src from the data-src on each button

        var $videoSrc;
        $('.video-btn').click(function() {
            $videoSrc = $(this).data( "src" );
        });
        console.log($videoSrc);



// when the modal is opened autoplay it
        $('#myModal').on('shown.bs.modal', function (e) {

// set the video src to autoplay and not to show related video. Youtube related video is like a box of chocolates... you never know what you're gonna get
            $("#video").attr('src',$videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0&output=embed" );
        })



// stop playing the youtube video when I close the modal
        $('#myModal').on('hide.bs.modal', function (e) {
            // a poor man's stop video
            $("#video").attr('src',$videoSrc);
        })






// document ready
    });
</script>

<!-- ============================ Call To Action ================================== -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.Layouts.frontendlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\htdocs\propTesting\pecustomeruat\resources\views/Frontend/singleproperty.blade.php ENDPATH**/ ?>