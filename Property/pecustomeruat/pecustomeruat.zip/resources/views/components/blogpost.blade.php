       <!-- Single blog Grid -->
       <div class="col-lg-4 col-md-6">
         <div class="blog-wrap-grid">

             <div class="blog-thumb">
                 <a href="{{route('blogdetails')}}"><img src="{{url('/')}}/assets/frontend/img/p-11.jpg" class="img-fluid" alt="" /></a>
             </div>

             <div class="blog-info">
                 <span class="post-date"><i class="ti-calendar"></i>30 july 2018</span>
             </div>

             <div class="blog-body">
                 <h4 class="bl-title"><a href="{{route('blogdetails')}}">Why people choose listio for own properties</a></h4>
                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore. </p>
                 <a href="{{route('blogdetails')}}" class="bl-continue">Continue</a>
             </div>

         </div>
     </div>

     <!-- Single blog Grid -->
     <div class="col-lg-4 col-md-6">
         <div class="blog-wrap-grid">

             <div class="blog-thumb">
                 <a href="{{route('blogdetails')}}"><img src="{{url('/')}}/assets/frontend/img/p-8.jpg" class="img-fluid" alt="" /></a>
             </div>

             <div class="blog-info">
                 <span class="post-date"><i class="ti-calendar"></i>10 August 2018</span>
             </div>

             <div class="blog-body">
                 <h4 class="bl-title"><a href="{{route('blogdetails')}}">List of benifits and impressive listeo services</a></h4>
                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore. </p>
                 <a href="{{route('blogdetails')}}" class="bl-continue">Continue</a>
             </div>

         </div>
     </div>

     <!-- Single blog Grid -->
     <div class="col-lg-4 col-md-6">
         <div class="blog-wrap-grid">

             <div class="blog-thumb">
                 <a href="blog-detail.html"><img src="{{url('/')}}/assets/frontend/img/p-10.jpg" class="img-fluid" alt="" /></a>
             </div>

             <div class="blog-info">
                 <span class="post-date"><i class="ti-calendar"></i>30 Sep 2018</span>
             </div>

             <div class="blog-body">
                 <h4 class="bl-title"><a href="news-detail.html">What people says about listio properties</a></h4>
                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore. </p>
                 <a href="news-detail.html" class="bl-continue">Continue</a>
             </div>

         </div>
     </div>
