<?php

return [


    'label_company_name' => 'Future Orbit',
    'label_enable_javascript' => 'Please enable JavaScript to continue',
    'label_invalid_login'=> 'Invalid Login Or Account suspended',
    'all_rights_reserved'=>'All rights reserved.',
    'label_staff_login_details'=>'Staff Login Details.'

];
