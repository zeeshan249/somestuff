<?php

return [

    'companyLogoImageUrl' => env('MIX_COMPANY_LOGO_IMAGE_URL', ''),
    'companyLoginImageUrl' => env('MIX_LOGIN_IMAGE_URL', ''),

];
